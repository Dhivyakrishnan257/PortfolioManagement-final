var express = require('express');
var app = express();
var path = require('path');
var logger = require('morgan');
var DOMParser = require('xmldom').DOMParser;
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var register=require('./routes/register');
var authenticate=require('./routes/authenticate');
var mongoUtil = require("./db/mongoUtil");
var mongodb = require('mongodb');
var mongoClient = mongodb.MongoClient;
var url = 'mongodb://10.219.85.96:27017/Portfolio-Management';
var parseString = require('xml2js').parseString;
var xml2js = require('xml2js');
var jwt = require("jsonwebtoken");
var temp=require("./routes/searchTerm");
var gen=require("./routes/generator");
var skillAutoComplete=require('./routes/skillAutoComplete');
var del=require("./routes/deleteChicklet");
var Promise = require('promise');
var CreatePortfolio= require('./routes/CreatePortfolio');
var UploadSection= require('./routes/UploadSection');
var UploadPortfolioDefinition= require('./routes/UploadPortfolioDefinition');
var RendererApi= require('./routes/RendererApi');
var chickletdata=require('./routes/chicklet');
var PortfolioAutoComplete=require("./routes/PortfolioAutoComplete");
var profileAutoComplete=require('./routes/profileAutoComplete');
var userPortfolio=require('./routes/userPortfolio');
var testingPortfolioStructure=require('./routes/testingPortfolioStructure');
var authenticateApps = require('./routes/authenticateApps');
var theme=require('./routes/theme');
var db;
app.use(function(req,res,next) {
  if(db == undefined) {
    mongoUtil.getConnection("mongodb://10.219.85.96:27017/Portfolio-Management", function(err,_db) {
      db = _db;
      next();
    });
  }
  else {
    next();
  }
});
var Data=require('./routes/cache');
var postdata=require("./routes/postdata");
var delchick=require("./routes/delchick");
var smartQuestions = require("./routes/smartQuestions.route.js");
var chicklet = require("./routes/addChickletData.js");
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.use('/register',register);
app.use('/apps',authenticateApps);
app.use('/profile/:id/:portfolioId',express.static(path.join(__dirname, 'public')));
app.use('/profile/:id',express.static(path.join(__dirname, 'public')));
app.use('/questions',smartQuestions);
app.use('/', Data);
app.use('/chicklets',chicklet);
app.use('/api', postdata);
app.use('/',gen);
app.use('/', delchick);
app.use('/',temp);
app.use('/',del);
app.use('/',skillAutoComplete);
app.use('/',chickletdata);
app.use('/',CreatePortfolio);
app.use('/',profileAutoComplete);
app.use('/',PortfolioAutoComplete);
app.use('/',userPortfolio);
app.use('/',testingPortfolioStructure)
app.use('/',UploadPortfolioDefinition);
app.use('/',RendererApi);
app.use('/api',authenticate);
app.use('/',theme);
app.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});

if (app.get('env') === 'development') {
  app.use(function(err, req, res, next) {
    res.status(err.status || 500);
    res.render('error.jade', {
      message: err.message,
      error: err
    });
  });
}

app.use(function(err, req, res, next) {
  res.status(err.status || 500);
  res.render('error.jade', {
    message: err.message,
    error: {}
  });
});
module.exports = app;
