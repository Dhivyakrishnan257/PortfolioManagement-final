function isEmptyObject(o) {
  return Object.keys(o).every(function(x) {
      return o[x]===''||o[x]===null;  // or just "return o[x];" for falsy values
  });
}

function processSectionDisplay(type,resources) {
  if (type=="profile"){
  for(counter=0; counter < resources.profiles.sections.length; counter++){
     for (counterChicklets = 0; counterChicklets < resources.profiles.sections[counter].chicklets.length; counterChicklets++){
       for (counterChickletsData = 0; counterChickletsData < Object.keys(resources.profiles.sections[counter].chicklets[counterChicklets].chicklet_data).length; counterChickletsData++){
         var value = resources.profiles.sections[counter].chicklets[counterChicklets].chicklet_data[Object.keys(resources.profiles.sections[counter].chicklets[counterChicklets].chicklet_data)[counterChickletsData]]["value"] ? resources.profiles.sections[counter].chicklets[counterChicklets].chicklet_data[Object.keys(resources.profiles.sections[counter].chicklets[counterChicklets].chicklet_data)[counterChickletsData]]["value"] : "";
         if(value !=""){
               resources.profiles.sections[counter]["showSection"] = true;
               break;
         }
     }
     if (resources.profiles.sections[counter]["showSection"]){
       break;
     }
     resources.profiles.sections[counter]["showSection"] = false;
   }
  }
  return resources;
  }
  else if(type=="section") {
    for (counterChicklets = 0; counterChicklets < resources.chicklets.length; counterChicklets++) {
      for (counterChickletsData = 0; counterChickletsData < Object.keys(resources.chicklets[counterChicklets].chicklet_data).length; counterChickletsData++){
      var value = resources.chicklets[counterChicklets].chicklet_data[Object.keys(resources.chicklets[counterChicklets].chicklet_data)[counterChickletsData]]["value"] ? resources.chicklets[counterChicklets].chicklet_data[Object.keys(resources.chicklets[counterChicklets].chicklet_data)[counterChickletsData]]["value"] : "";
      if(value !="") {
            resources["showSection"] = true;
            break;
      }
    }
    if(resources["showSection"])
      break;

    resources["showSection"] = false;
  }
  return resources;
  }
}

angular.module('portfolio')
  .controller('mainCtrl',["$scope","profile","theming","$mdDialog","$http","$window","$routeParams","$location","$rootScope","question","$timeout",function($scope,profile,theming,$mdDialog,$http,$window,$routeParams,$location,$rootScope,question,$timeout) {
    $rootScope.profilePath = $location.path().split('/profile/')[1];
    $rootScope.profileId = $rootScope.profilePath.split('/')[0];
    $rootScope.portfolioId = $rootScope.profilePath.split('/')[1];

    if($window.localStorage["userId"] == $rootScope.profileId) {
      $rootScope.editEnabled = true;
    }
    else {
      $rootScope.editEnabled = false;
    }



    question.getData($rootScope.profileId).success(function(qu){
        $scope.mongoId = qu[0];

    });


    $scope.popupQuestion = function(resource) {
      var chicklets = [];
      if($scope.mongoId.chickletId.length >0)
      {
      for(var section of resource.profiles.sections){
        for(var chicklet of section.chicklets) {
          for(var chickletId of $scope.mongoId.chickletId){
            if(chicklet._id === chickletId) {
              chicklets.push({chickletData:chicklet.chicklet_data,chickletDirectiveName: chicklet['chicklet-directive-name']});
            }
          }
        }
      }

    $timeout(function() {
      $mdDialog.show({
        controller: 'popupQuestionCtrl',
        templateUrl:'/views/mastertemplate.html',
        clickOutsideToClose: true,
        escapeToClose: true,
        resolve:{
          chicklets: function() {
            return chicklets;
          }
        }
      });
    },5000)
    }
};

    profile.getData($rootScope.profileId,$rootScope.portfolioId).success(function(resources) {
      $scope.resource =   processSectionDisplay("profile",resources[0]);
      profile.resource = $scope.resource;
      if($rootScope.portfolioId=="")
        $scope.popupQuestion($scope.resource);

    });


    theming.getData($rootScope.portfolioId).success(function(data){
      $scope.themeData=data;
      var im="/"+$scope.themeData["image"]+".jpg";
      $scope.bg='url('+im+')';
    });

    var config = {
      headers:{ 'Content-Type':'application/JSON'}
    }

  $scope.logout = function() {
          $window.localStorage.removeItem("authToken");
          $window.location.href="/login.html";
  };
  $scope.home=function(){
    $window.location.href="/dnd_index.html";
  }
  $scope.showChickletList = function(ev) {
    $mdDialog.show({
      templateUrl:'/views/addCard.tmpl.html',
      targetEvent: ev,
      controller:"addCardCtrl",
      fullscreen: true
    });
  };

  $scope.DateConverter=function(value){
    value=new Date(value).toString();
    return value;
  }

  $scope.isObject = function(object,key) {
    if(angular.isObject(object[key])) {
      return true;
    }
    return false;
  }
}]);
