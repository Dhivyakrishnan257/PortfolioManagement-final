angular.module('portfolio')
  .service('question', function($http) {
    this.getData = function(profileId) {
      return $http.get('/questions/'+profileId);
    };
  });
