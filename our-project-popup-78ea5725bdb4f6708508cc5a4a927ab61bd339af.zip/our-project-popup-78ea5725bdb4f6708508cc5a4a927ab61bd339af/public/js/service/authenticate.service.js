angular.module('portfolio')
.service('authenticate', function($http,$window,$location,$mdToast) {
  this.login = function(email,password) {
    var loginCredentials = { "email":email,"password":password }
    return $http.post('/api/authenticate',loginCredentials).success(function (user) {
    $window.localStorage["authToken"] = user.token;
      $window.localStorage["userId"] = user.userId;
      $window.location.href = "/dnd_index.html";
    }).error(function() {
      $mdToast.show($mdToast.simple().textContent("Invalid User").action("OK").position("top right").hideDelay(4000));
  });
}});
