var app = angular.module('app', ['ngMaterial', 'dndLists', 'ngRoute'])
    .config(function($routeProvider,$httpProvider,$windowProvider,$mdThemingProvider,$locationProvider,themingServiceProvider) {
      var themingServiceObj = themingServiceProvider.$get();
        var themeData = themingServiceObj.getTheme();
        var themeService = $mdThemingProvider.$get();
        themeData.then(function(response){
                   myThemes = response.data;
                   for( var i=0;i<myThemes.length;i++ ){
                       $mdThemingProvider.theme(myThemes[i].theme)
                        .primaryPalette(myThemes[i].primaryPalette)
                        .accentPalette(myThemes[i].accentPalette)
                        .backgroundPalette(myThemes[i].accentPalette);
                        themeService.generateTheme(myThemes[i].theme);
                   }
                   $mdThemingProvider.alwaysWatchTheme(true);
                  });
        $routeProvider.when('/', {
                templateUrl: '../Portfolio_index.html',
                controller: 'Ctrl2'
            })
            .when('/dndCreate', {
                templateUrl: '../dnd_template.html'
            });
    })
    .service('themingService', function($http) {
           this.getTheme = function() {
             return $http.get('/themes');
           }
     })
     .service('theming', ["$http", function ($http) {
       this.getData = function(portfolioId) {
         if(portfolioId === "")
         {
           return $http.get('/getThemeData');
         }
         return $http.get('/getThemeData/'+portfolioId);
         }
     }])
    .controller('Ctrl', function($scope, $rootScope, $http, $mdSidenav, $compile, $document, $mdDialog, $window, editService, $timeout,getSkills,theming) {
        $scope.customFullscreen = false;
        $scope.show_section = true;
        $scope.chicklets = [];
        $scope.rendererObject = {};
        $scope.global_chicklet_obj = {};
        $scope.currentSection = [];

        $http.get("/CreatePortfolio/sections").success(function(data) {
            $scope.section;
            $scope.section = data;
        });
        $http.get("/chicklet").success(function(data) {
            $scope.chickletData;
            $scope.chickletData = data[0].chicklet[0];

        });

        $scope.getImage=function(im)
        {
          return "../"+im+".jpg";
        }

        $http.get("/themeList").success(function(data) {
            $scope.cardThemes=data.CardThemes;
            $scope.fontStyle=data.FontStyle;
            $scope.fontColor=data.FontColor;
            $scope.bgImage=data.BackgroundImage;
            $scope.bgimage=[];
            for(var i=0;i<$scope.bgImage.length;i++)
            {
                $scope.bgimage[i]="../"+$scope.bgImage[i]+".jpg";
            }

        });

        $scope.updateTheme=false;
        if(editService.edit == true){
          $scope.updateTheme=true;

        theming.getData(editService.final.portfolioId).success(function(data){
          $scope.curr_image=data["image"];
          $scope.curr_cardTheme=data["cardTheme"];
          $scope.curr_fontColor=data["fontColor"];
          $scope.curr_fontStyle=data["fontStyle"];
        });
      }
      else{
        theming.getData("").success(function(data){
          $scope.curr_image=data["image"];
          $scope.curr_cardTheme=data["cardTheme"];
          $scope.curr_fontColor=data["fontColor"];
          $scope.curr_fontStyle=data["fontStyle"];
        });

      }
      if (editService.edit == true) {
            $scope.portfolioMongoId=editService.final._id;
            $scope.portfolio_Id_mongo=editService.final.portfolioId;
            $scope.PortfolioName = editService.final.PortfolioName;
            $scope.rendererObject = editService.final.rendererObject;
            $scope.currentSection = editService.final.currentSection;
            $scope.global_chicklet_obj = editService.final.global_chicklet_obj;
            angular.element(document.querySelector('[dnd="true"]')).html("");
            var htmlText = '';
            angular.forEach($scope.currentSection, function(section) {
                angular.forEach($scope.rendererObject, function(value, key) {
                    if (section == key) {
                        htmlText = htmlText + "<" + value.section_directive_name_dnd + " edit='true' template='" + editService.final.html[value.section_directive_name_dnd] + "' section-name=" + value.section_directive_name + " section-dnd-name=" + value.section_directive_name_dnd + " show-advanced=showAdvanced  remove-button=remove_button remove-section=remove_section remove-chicklet=remove_chicklet drop-chicklet=dropChicklet display-name=" + value.section_name + " ></" + value.section_directive_name_dnd + ">";
                    }
                });
            });

            htmlText = htmlText.replace(/ng-transclude=\"\"/g, "");
            var compile = $compile(htmlText)($scope);
            angular.element(document.querySelector('[dnd="true"]')).append(compile);
            editService.edit = false;
        }
        $scope.back=function(){
          $scope.show_section = true;
        }
        $scope.droppedSection = function(event, index, item, external) {
            if ($scope.currentSection.indexOf(item["section"].section_directive_name) == -1) {
                var obj1 = new Object();
                obj1 = item.chicklet
                $scope.global_chicklet_obj[item['section'].section_directive_name] = obj1;
                $scope.rendererObject[item["section"].section_directive_name] = {};
                $scope.rendererObject[item["section"].section_directive_name]['section_id'] = item["section"].section_id;
                $scope.rendererObject[item["section"].section_directive_name]['section_directive_name_dnd'] = item["section"].section_directive_name_dnd;
                $scope.rendererObject[item["section"].section_directive_name]['section_directive_name'] = item["section"].section_directive_name;
                $scope.rendererObject[item["section"].section_directive_name]['placeholders'] = item["section"]['placeholders'];
                $scope.rendererObject[item["section"].section_directive_name]['section_name'] = item["section"].section_name;
                $scope.rendererObject[item["section"].section_directive_name]['chicklets'] = {};
                $scope.currentSection.push(item["section"].section_directive_name);
                var htmlText = $compile('<' + item["section"].section_directive_name_dnd + ' edit="false" section-name=' + item["section"].section_directive_name + ' section-dnd-name=' + item["section"].section_directive_name_dnd + ' show-advanced=showAdvanced  remove-button=remove_button remove-section=remove_section remove-chicklet=remove_chicklet drop-chicklet=dropChicklet display-name='+ '\"'+item["section"].section_name +'\"'+' ></' + item["section"].section_directive_name_dnd + '>')($scope);
                angular.element(event.currentTarget).append(htmlText);
              }
        };
        $scope.remove_button = function(event, sectionName) {
            $scope.chicklets = $scope.global_chicklet_obj[sectionName];
            $scope.show_section = false;
            angular.element(event.currentTarget.parentElement).removeClass("button_visible").addClass("button_disappear");
            angular.element(event.currentTarget.parentElement.nextElementSibling).removeClass("dnd_disappear").addClass("dnd_appear");
          };
          $scope.dropChicklet = function(event, index, item, external, sectionName) {
            event.stopPropagation();
            item["placeholderId"] = event.srcElement.attributes.slot.value;
            $scope.rendererObject[sectionName]['chicklets'][item["placeholderId"]] = item;
            if ($scope.chickletData[item['chicklet-directive-name']].multivalue == "true") {
                var htmlText = $compile('<md-button class="md-fab md-mini filter_button filter_class" chicklet="' + item["chicklet-directive-name"] + '" section="' + sectionName + '" placeholder="' + item["placeholderId"] + '"  ng-click="showAdvanced()($event)" aria-label="close chicklet"> <md-icon class="material-icons">build</md-icon> </md-button>')($scope);
                angular.element(event.currentTarget).html("<p>" + item["chicklet-name"] + "</p>").addClass('chicklet_display');
                angular.element(event.currentTarget).append(htmlText);
            } else {
                angular.element(event.currentTarget).html("<p>" + item["chicklet-name"] + "</p>").addClass('chicklet_display');
            }
          };
          $scope.remove_section = function(event, sectionNameDnd, sectionName) {
            angular.element(document).find(sectionNameDnd).remove();
            delete $scope.rendererObject[sectionName];
            $scope.show_section = true;
            var index = $scope.currentSection.indexOf(sectionName);
            $scope.currentSection.splice(index, 1);
        };
        $scope.remove_chicklet = function(event, sectionName) {
            angular.element(event.currentTarget.parentElement).removeClass("dnd_appear").addClass("dnd_disappear");
            angular.element(event.currentTarget.parentElement.previousElementSibling).removeClass("button_disappear").addClass("button_visible");
            delete $scope.rendererObject[sectionName]['chicklets'][event.currentTarget.nextElementSibling.attributes.slot.value];
            angular.element(event.currentTarget.nextElementSibling).empty().removeClass('chicklet_display');

        };

        $scope.preview=function(){

        };

        $scope.changeCardTheme=function(a){

          $scope.curr_cardTheme=a;
        };

        $scope.changeFontColor=function(a){

          $scope.curr_fontColor=a;
        };

        $scope.changeFontStyle=function(a){

          $scope.curr_fontStyle=a;
        };

        $scope.changeImage=function(a){

          $scope.curr_image=a;
        };

        $scope.savePortfolio=function() {
          var obj={};
          var theme_id;
          obj["cardTheme"]=$scope.curr_cardTheme;
          obj["fontColor"]=$scope.curr_fontColor;
          obj["fontStyle"]=$scope.curr_fontStyle;
          obj["image"]=$scope.curr_image;
          if($scope.updateTheme==true){
          $http.post("/saveTheme/"+editService.final.portfolioId,obj).success(function(response) {
              $scope.theme_id=response;
              $scope.createPortfolio();
            });
        }
        else{
          $http.post("/saveTheme",obj).success(function(response) {
            $scope.theme_id=response;
            $scope.createPortfolio();
            });
          }
        }

        $scope.toggleLeft = buildToggler('left1');
        function buildToggler(componentId) {
          return function() {
            $mdSidenav(componentId).toggle();
          }
        }

        $scope.createPortfolio = function() {
            $scope.rendererArray = [];
            $scope.finalJson = {};
            $scope.finalJson['sections'] = [];
            $scope.rendererObject_temp = JSON.parse(JSON.stringify($scope.rendererObject));
            angular.forEach($scope.rendererObject_temp, function(value, sectionKey) {
                if ($scope.rendererArray.indexOf(sectionKey) == -1) {
                    $scope.rendererArray.push(sectionKey);
                    $scope.rendererObject_temp[sectionKey]['chicklet'] = [];
                    angular.forEach($scope.rendererObject_temp[sectionKey]['chicklets'], function(value, key) {
                        $scope.rendererObject_temp[sectionKey]['chicklet'].push(value);
                    });
                    delete $scope.rendererObject_temp[sectionKey]['chicklets'];
                    $scope.finalJson['sections'].push(value);
                }
              });
            var data = {};
            data['global_chicklet_obj'] = $scope.global_chicklet_obj;
            data['userId'] = $window.localStorage["userId"];
            data['portfolioDef'] = $scope.finalJson;
            angular.forEach(data['portfolioDef'].sections, function(value, key) {
                if (data['portfolioDef'].sections[key]['chicklet']) {
                    data['portfolioDef'].sections[key]['chicklets'] = data['portfolioDef'].sections[key]['chicklet'];
                    delete data['portfolioDef'].sections[key]['chicklet'];
                }
            });
            var html = {};
            angular.forEach($scope.rendererObject, function(value, key) {
                html[value.section_directive_name_dnd] = angular.element(document.querySelector(value.section_directive_name_dnd))[0].innerHTML;

            });
            data['portfolioMongoId']= $scope.portfolioMongoId;

            data['portfolioId']=$scope.portfolio_Id_mongo;
            data['portfolioHTML'] = html;
            data['currentSection'] = $scope.currentSection;
            data['rendererObject'] = $scope.rendererObject;
            data['PortfolioName'] = $scope.PortfolioName;
            data['filterable_fields'] = $scope.filterable_fields;
            data['themeId']=$scope.theme_id;
            $http.post('/UploadPortfolioDefinition', data).success(function(response) {

            });
            $window.alert("Portfolio Definition is created !")
            $window.location.href="/dnd_index.html";
        };

          $scope.gotoHome=function(){
          $window.location.href="/dnd_index.html";
        }

          $scope.showAdvanced = function(ev) {
            if (!ev)
            ev = event;
            var chicklet = ev.currentTarget.attributes.chicklet.value;
            var sectionName = ev.currentTarget.attributes.section.value;
            var placeholderId = ev.currentTarget.attributes.placeholder.value;
            if (!("filter" in $scope.rendererObject[sectionName]['chicklets'][placeholderId])) {
              $scope.rendererObject[sectionName]['chicklets'][placeholderId]['filter'] = [{}];
            } else {
            }
            $scope.filterable_fields = [];
            angular.forEach($scope.chickletData[chicklet]['fields'][0], function(value, key) {
                if ($scope.chickletData[chicklet]['fields'][0][key].filtrable == 'true') {
                    $scope.filterable_fields.push($scope.chickletData[chicklet]['fields'][0][key]);
                }
            });
            $mdDialog.show({
                    controller: DialogController,
                    resolve: {
                        filterable_fields: function() {
                            return $scope.filterable_fields;
                        },
                        rendererObject: function() {
                            return $scope.rendererObject[sectionName]['chicklets'][placeholderId];
                        }
                    },
                    templateUrl: '../views/dialog1.tmpl.html',
                    parent: angular.element(document.body),
                    targetEvent: ev,
                    clickOutsideToClose: true,
                    fullscreen: $scope.customFullscreen // Only for -xs, -sm breakpoints.
                })
                .then(function(final) {
                  var i=final.length;
                  while(i--){
                    if(final[i].textValue==null || final[i].selectedField=="None"|| final[i].selectedRelation=="None"){
                      final.splice(i,1);
                    }
                  }
                  $scope.rendererObject[sectionName]['chicklets'][placeholderId]['filter'] = final;
                }, function() {
                    $scope.status = 'You cancelled the dialog.';
                });
        };

        function DialogController($scope, filterable_fields, $mdDialog, rendererObject) {
            $scope.selectedItem = [];
            $scope.filterObject = rendererObject['filter'];
            $scope.isDisabled = false;
            $scope.noCache = false;
            $scope.searchText = "";
            $scope.Person = [];
            $scope.selectedItem = [];
            $scope.isDisabled = false;
            $scope.noCache = false;
            $scope.selectedItemChange = function(item) {
                 }
                 $scope.searchTextChange = function (str) {
                   return getSkills.getSkill(str);
                 }
            $scope.filterable_fields = filterable_fields;

            $scope.addFilter = function() {
                $scope.filterObject.push({});
            };
            $scope.removeFilter = function(index) {
                $scope.filterObject.splice(index, 1);
                angular.forEach($scope.filterObject, function(value, key) {});
            };
            $scope.array = [{
                "type": "text",
                "value": "contains"
            }, {
                "type": "text",
                "value": "equals"
            }, {
                "type": "number",
                "value": "equal"
            }, {
                "type": "number",
                "value": "greaterThan"
            }, {
                "type": "number",
                "value": "lessThan"
            }];
            $scope.relationArray = function(input) {
              if (input.type == "text") {
                    return ['Contains', 'Equals'];
                } else if (input.type == "number") {
                    return ['Equals', 'Less than', 'Greater than'];
                }
            };
            $scope.hide = function() {
                $mdDialog.cancel();
            };
            $scope.cancel = function() {
                $mdDialog.hide($scope.filterObject);
            };
        };

        function DialogController2($scope, portfolios, $mdDialog) {
            $scope.portfolio = portfolios;
            $scope.selectedPortfolio = function(index) {
            $scope.selected_index = portfolios[index];
            }
            $scope.hide = function() {
                $mdDialog.cancel();
            };
            $scope.cancel = function() {
                $mdDialog.hide($scope.selected_index);
            };
        };
    }).controller('Ctrl2', function($scope, $rootScope, $http, $mdSidenav, $compile, $document, $mdDialog, $window, $location, editService, GetPortfolios, GetProfiles, $timeout) {
        $scope.searchText = "";
        $scope.Person = [];
        $scope.selectedItem = [];
        $scope.isDisabled = false;
        $scope.noCache = false;
        $scope.portfolio_id;
        $scope.profile_id;
        $scope.viewProfile=function(){
          $window.location.href = "/profile/"+$window.localStorage["userId"];
        };
        $scope.searchPortfolio = function(str) {
            return GetPortfolios.getPortfolio(str);
        }
        $scope.searchProfile = function(str) {
            return GetProfiles.getProfile(str);
        }
        $scope.logout = function() {
                 $window.localStorage.removeItem("authToken");
                 $window.location.href="/login.html";
         }
        $scope.search = function(profile_id, portfolio_id) {
            if(portfolio_id==null) $window.location.href = "/profile/" + profile_id.userProfileId
            $window.location.href = "/profile/" + profile_id.userProfileId + "/" + portfolio_id.portfolioId;
        }

        $scope.edit = function(ev) {
          $http.get('userPortfolio/' + $window.localStorage["userId"]).success(function(data) {
                $mdDialog.show({
                        controller: DialogController2,
                        resolve: {
                            portfolios: function() {
                                return data;
                            }
                        },
                        templateUrl: '../views/portfolioDialog.tmpl.html',
                        parent: angular.element(document.body),
                        targetEvent: ev,
                        clickOutsideToClose: true,
                        fullscreen: $scope.customFullscreen // Only for -xs, -sm breakpoints.
                    })
                    .then(function(final) {
                        editService.edit = true;
                        editService.final = final;
                        $location.path('/dndCreate');

                    }, function() {
                        $scope.status = 'You cancelled the dialog.';
                    });
            });

            function DialogController2($scope, portfolios, $mdDialog, $rootScope, GetPortfolios,$window) {

              $location.path('/');

                $scope.portfolio = portfolios;
                $scope.selectedPortfolio = function(index) {
                    $scope.selected_index = portfolios[index];
                    $mdDialog.hide($scope.selected_index);
                }

                $scope.hide = function() {
                    $mdDialog.cancel();
                    };

                $scope.cancel = function() {
                    $mdDialog.cancel();
                };
              };
            };
        $scope.create = function() {
          $timeout(function() {
            editService.edit = false;
            $location.path('/dndCreate');
          },100);
        };
}).factory('GetPortfolios', function($http, $q) {
        return {
            getPortfolio: function(str) {
              return $http.get("PortfolioAutoComplete/" + str).then(function(response) {
                if (typeof response.data === 'object') {
                        return response.data;
                    } else {
                        return $q.reject(response.data);
                    }
                });
            }
        };
    }).factory('GetProfiles', function($http, $q) {
        return {
            getProfile: function(str) {
                return $http.get("profileAutoComplete/" + str).then(function(response) {

                    if (typeof response.data === 'object') {
                        return response.data;
                    } else {
                        return $q.reject(response.data);
                    }
                });
            }
        };
    })
    .factory('getSkills', function($http, $q) {
        return {
            getSkill: function(str) {
                return $http.get("skillAutoComplete/" + str).then(function(response) {

                    if (typeof response.data === 'object') {
                        return response.data;
                    } else {
                        return $q.reject(response.data);
                    }
                });
            }
        };
    }).service('editService', function() {
        this.final;
        this.edit = false;
    });
