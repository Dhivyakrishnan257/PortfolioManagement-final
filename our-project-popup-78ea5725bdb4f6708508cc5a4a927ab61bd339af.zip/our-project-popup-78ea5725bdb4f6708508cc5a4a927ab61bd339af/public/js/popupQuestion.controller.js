angular.module('portfolio')
  .controller('popupQuestionCtrl',["$scope","$http","chicklets","$mdDialog","profile","$rootScope","$window",function($scope,$http,chicklets,$mdDialog,profile,$rootScope,$window){
    $scope.chicklets = chicklets;
    $scope.resource=profile.resource;
    this.save = function(){
      $scope.resource.profiles.sections.forEach(function(section) {
      var fd = new FormData();
      fd.append("resource",angular.toJson($scope.resource));
      var res= $http.patch("/api/postdata",fd,{
        transformRequest: angular.identity,
        headers: {
        "Content-Type": undefined
        }
        });
      res.success(function(data, status, headers, config) {
      section = processSectionDisplay("section",section);
      $mdDialog.cancel();
      });
      });
      };
    var self=this;
    $scope.cancel = function() {
        self.save();
        $mdDialog.cancel();
    };

    var index = 0;
    $scope.chickletData = $scope.chicklets[index].chickletData;
    $scope.template = '/views/'+$scope.chicklets[index].chickletDirectiveName+'.cui.html';

    $scope.onNext = function(){
      if(index < $scope.chicklets.length-1) {
      var chicklet = $scope.chicklets[++index];
      $scope.chickletData = chicklet.chickletData;
      $scope.template = '/views/'+chicklet.chickletDirectiveName+'.cui.html';
    } else
    {
  self.save();

};
};
}]);
