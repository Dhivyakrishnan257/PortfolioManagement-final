function authInterceptor($window) {
 return {
   // automatically attach Authorization header
   request: function(config) {
     var token = $window.localStorage["authToken"];
     if(config.url.indexOf('localhost:8080') === 0 && token) {
       config.headers.add("x-access-token",token);
     }
     else if(!token) {
       debugger;
       $window.location.href="/login.html";
       return;
     }
     return config;
   },
   // If a token was sent back, save it
   response: function(res) {
         if(res.config.url.indexOf('localhost:8080') === 0 && res.data.token) {
         $window.localStorage["authToken"]=res.data.token;
     }
     return res;
   }
 }
}


angular.module('portfolio', ['ngMaterial' , 'ngRoute','xeditable'])
.factory('authInterceptor',authInterceptor)
.config(function($httpProvider,$windowProvider,$mdThemingProvider,$locationProvider,themingServiceProvider) {
   var $window = $windowProvider.$get();
   $httpProvider.interceptors.push('authInterceptor');
   $mdThemingProvider.theme('grey')
   .primaryPalette('orange')
   .backgroundPalette('grey').dark();
  var themingServiceObj = themingServiceProvider.$get();
    var themeData = themingServiceObj.getTheme();
    var themeService = $mdThemingProvider.$get();
    themeData.then(function(response){
               myThemes = response.data;
               for( var i=0;i<myThemes.length;i++ ){
                   $mdThemingProvider.theme(myThemes[i].theme)
                    .primaryPalette(myThemes[i].primaryPalette)
                    .accentPalette(myThemes[i].accentPalette)
                    .backgroundPalette(myThemes[i].backgroundPalette);

                    themeService.generateTheme(myThemes[i].theme);
               }
          $mdThemingProvider.alwaysWatchTheme(true);
  });
 $locationProvider.html5Mode({enabled:true,requireBase:false});
 })
 .service('themingService', function($http) {
        this.getTheme = function() {
          return $http.get('/themes');
        }
          })
 .run(function(editableOptions,editableThemes){
   editableThemes['angular-material'] = {
    formTpl:      '<form class="editable-wrap"></form>',
    noformTpl:    '<span class="editable-wrap"></span>',

    controlsTpl:  '<md-input-container class="editable-controls" ng-class="{\'md-input-invalid\': $error}"></md-input-container>',
    inputTpl:     '',
    errorTpl:     '<div ng-messages="{message: $error}"><div class="editable-error" ng-message="message">{{$error}}</div></div>',
    buttonsTpl:   '<span class="editable-buttons"></span>',
    submitTpl:    '<md-button type="submit" class="md-primary">save</md-button>',
    cancelTpl:    '<md-button type="button" class="md-warn" ng-click="$form.$cancel()">cancel</md-button>'
  };
  editableOptions.theme = 'angular-material';
});
