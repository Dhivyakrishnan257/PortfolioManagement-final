angular.module('portfolio')
.directive('summaryWithRoles',function(){
  return{
    templateUrl:'../js/directives/professional/summaryWithRoles/summaryWithRoles.temp.html',
    scope:{
      sectionName:'@',
      chickletPath: '=chickletPath',
      theming : '='
    },
    controller:function($scope){
      $scope.chickletData = $scope.chickletPath['chicklet_data'];
      $scope.chickletName = $scope.chickletPath['chickletid'];
  }
}
});
