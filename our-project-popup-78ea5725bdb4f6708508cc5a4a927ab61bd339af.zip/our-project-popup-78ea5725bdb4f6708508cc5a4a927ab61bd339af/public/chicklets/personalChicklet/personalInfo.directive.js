angular.module('portfolio')
 .directive('personalInfo',function() {
 return {
     templateUrl: 'chicklets/personalChicklet/personal.tmpl.html',
     scope: {
         sectionName:'@',
         chickletPath: '=chickletPath',
         theming : '='
     },
     controller: function($scope,$rootScope,$mdDialog) {
       $scope.editEnabled = $rootScope.editEnabled;
       $scope.chickletData = $scope.chickletPath['chicklet_data'];
       $scope.chickletName = $scope.chickletPath['chickletid'];
       $scope.chicklets=$scope.chickletPath;
       $scope.personalModal=function(chickletData,sectionName,chickletName,chicklets){
       $mdDialog.show({
             templateUrl:'/views/personal_modal.html',
             locals: { chickletData: chickletData,
                       sectionName:sectionName,
                       chickletName:chickletName,
                     chicklets:chicklets,
                   theme : $scope.theming["cardTheme"]},
             controller:"DialogController"
       });
       };
       $scope.deletechicklet=function(chickletData,sectionName,chickletName,chicklets){
       $mdDialog.show({
               templateUrl:'/views/delete_chicklet_modal.html',
               locals: { chickletData: chickletData,
                         sectionName:sectionName,
                         chickletName:chickletName,
                       chicklets:chicklets,
                     theme : $scope.theming["cardTheme"]},
               controller:"DialogController"
         });
        };
     }
 }
});
