angular.module('portfolio')
 .directive('summaryInfoTwo',function() {
 return {
     templateUrl: '../js/directives/aboutMe/summaryTwoChicklet/summarytwo.tmpl.html',
     scope: {
         sectionName:'@',
         chickletPath: '<chickletPath',
         theming : '='
     },
     controller: function($scope) {
       $scope.chickletData = $scope.chickletPath['chicklet_data'];
       $scope.chickletName = $scope.chickletPath['chickletid'];

     }
 }
});
