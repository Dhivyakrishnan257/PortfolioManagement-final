angular.module('app')
.directive('professionalExpTwoDnd',function($compile){
    return {
      restrict:'CEA',
      templateUrl:function(elem,attr){
        if(attr.edit=="false"){
          return 'sections/professionalSectionTwo/professionalExpTwoDnd.tmpl.html';
        }else if (attr.edit=="true") {

                    return '';
        }
      },
      link:function($scope,elem,attr){
        if(attr.edit=="true"){
          elem.html('');
          var html=$compile(attr.template)($scope);
          elem.append(html);
        }
      }
      ,
      scope: {
        template:'@',
        edit:'=edit',
        sectionName: '@',
        displayName:'@',
        removeButton:'&',
        dropChicklet:'&',
        removeSection:'&',
        removeChicklet:'&',
        showAdvanced:'&',
        sectionDndName:'@'
      },
      transclude: {
        'placeholdertwo-s': '?placeholdertwoS',
        'placeholdertwo-r': '?placeholdertwoR',
        'placeholdertwo-p': '?placeholdertwoP'
      },
    }
  });
