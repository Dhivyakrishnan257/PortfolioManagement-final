angular.module('app')
  .directive('interestSectionDndTwo',function($compile){
      return {
        restrict:'CEA',
        templateUrl:function(elem,attr){
          if(attr.edit=="false"){
              return 'sections/interestTwo/interestdndtwo.tmpl.html';
          }else if (attr.edit=="true") {

                      return '';
          }
        },
        link:function($scope,elem,attr){
          if(attr.edit=="true"){
            elem.html('');
            var html=$compile(attr.template)($scope);
            elem.append(html);
          }
        }
        ,
        scope: {
          template:'@',
          edit:'=edit',
          sectionName: '@',
          displayName:'@',
          removeButton:'&',
          dropChicklet:'&',
          removeSection:'&',
          removeChicklet:'&',
          showAdvanced:'&',
          sectionDndName:'@'
        },
        transclude: {
          'placeholder-f': '?placeholderF',
          'placeholder-g': '?placeholderG',
          'placeholder-h': '?placeholderH',
          'placeholder-i': '?placeholderI',
          'placeholder-j': '?placeholderJ'
        },
      }
    });
