var express = require('express');
var router = express.Router();
var neo4j = require('neo4j-driver').v1;
var driver = neo4j.driver("bolt://10.219.93.21",neo4j.auth.basic('neo4j','1234'));
var session = driver.session();

router.get('/skillAutoComplete/:str',function(req,res,next)
{
      var queryString = 'MATCH (z:skills) where z.name starts with "'+ req.params.str + '" return z';
      session.run(queryString).then(function(skills) {
        var terms = [];
        skills.records.forEach(function(record) {
          var term = record._fields[0].properties.term;
          terms.push(term);
        });
        // console.log(terms);
        res.status(200).json(terms);
      }).catch(function(err) {
        console.log(err);
        res.status(500);
  });
});
module.exports = router;
