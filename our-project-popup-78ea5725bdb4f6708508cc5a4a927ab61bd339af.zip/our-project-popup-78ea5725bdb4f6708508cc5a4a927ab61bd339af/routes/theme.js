var express = require('express');
var router = express.Router();
var request = require('request');
var mongoUtil = require( '../db/mongoUtil' );
var jwt = require('jsonwebtoken');
var path = require('path');
var ObjectId = require("mongodb").ObjectID;

router.get('/themes', function(req, res) {
    var db = mongoUtil.getConnection();
    db.collection('theme').find().toArray(function(err, object) {
      res.json(object[0].CardThemes);
      res.status(200);
    });
});

router.get('/themeList',function(req,res) {
  var db = mongoUtil.getConnection();
  db.collection('theme').find().toArray(function(err, object) {
    res.json(object[0]);
    res.status(200);
  });
});

router.get('/getDefaultTheme',function(req,res){
  var db = mongoUtil.getConnection();
  db.collection('portfolio_theme').find().toArray(function(err, object) {
    res.json(object[0]._id);
    res.status(200);
  });
});

router.post('/saveTheme/:portfolioId?',function(req,res){
  var db = mongoUtil.getConnection();
  res.status(200);
  if(req.param("portfolioId")==undefined)
  {
      db.collection('portfolio_theme').insert(req.body, function(err, response) {
      id=response.insertedIds;
      res.send(id[0]);
    });
  }
  else {
        var portfolio_id=ObjectId(req.param("portfolioId"));
        db.collection('user_portfolio').find({"portfolioId":portfolio_id}).toArray(function(err, object) {
        if(object[0]==undefined)
        {
            db.collection('user_portfolio').find({"portfolioId":req.param("portfolioId")}).toArray(function(err, obj) {
            var theme_id=obj[0]["themeId"];

            db.collection('portfolio_theme').update({"_id":ObjectId(theme_id)},req.body,function(err, obj) {
              res.send(theme_id);
            });
          });
        }
      else{
          var theme_id=object[0]["themeId"];
          db.collection('portfolio_theme').update({"_id":ObjectId(theme_id)},req.body,function(err, obj) {
            res.send(theme_id);
        });
      }
    });
  }
});

router.get('/getThemeData/:portfolioId?',function(req,res){
  var db = mongoUtil.getConnection();
  if(req.param("portfolioId")==undefined)
  {
    db.collection('portfolio_theme').find({"_id":ObjectId("580b4e755513420f7ac4adb1")}).toArray(function(err, object) {
      res.send(object[0]);
    });
  }
  else {
    var portfolio_id=ObjectId(req.param("portfolioId"));
    db.collection('user_portfolio').find({"portfolioId":portfolio_id}).toArray(function(err, object) {
    if(object[0]==undefined)
    {
      db.collection('user_portfolio').find({"portfolioId":req.param("portfolioId")}).toArray(function(err, obj) {
        var theme_id=obj[0]["themeId"];
        if(theme_id==undefined)
        {
          db.collection('portfolio_theme').find({"_id":ObjectId("580b4e755513420f7ac4adb1")}).toArray(function(err, obj) {
            res.send(obj[0]);
          });
        }
        else{
        db.collection('portfolio_theme').find({"_id":ObjectId(theme_id)}).toArray(function(err, obj) {
          res.send(obj[0]);
        });
        }
      });
    }
    else{
      var theme_id=object[0]["themeId"];
      if(theme_id==undefined)
    {
      db.collection('portfolio_theme').find({"_id":ObjectId("580b4e755513420f7ac4adb1")}).toArray(function(err, object) {
        res.send(object[0]);
      });
    }
    else{
      db.collection('portfolio_theme').find({"_id":ObjectId(theme_id)}).toArray(function(err, object) {
        res.send(object[0]);
    });
    }
  }
});
}
});
module.exports = router;
