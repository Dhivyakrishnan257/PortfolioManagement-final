var express = require('express');
var router = express.Router();
var mongodb = require('mongodb');
var mongoClient = mongodb.MongoClient;
var RendererApiController=require('./RendererApi.controller.js');
var finalMerger=require('./merge.controller.js');
var url = 'mongodb://10.219.85.122:27017/Portfolio-Management';

router.get("/RendererApi/:profileId/:portfolioId?",function(req,res,next)
{
var  portfolioId = req.param("portfolioId");
var profileId = req.param("profileId");
var p1 = new Promise(function(resolve, reject) {
    RendererApiController.initialMerger(resolve, reject, portfolioId);
});
var p2 = new Promise(function(resolve, reject) {
    RendererApiController.profileData(resolve, reject, profileId);
});

Promise.all([p1, p2]).then(function(data) {
var portfolio = data[0][0];
var profile= data[1][0];
var p3 = new Promise(function(resolve, reject) {
    RendererApiController.filterAPI(resolve, reject, [portfolio]);
    });
    p3.then(function(data) {
      var p4=new Promise(function(resolve,reject){
        RendererApiController.filterProfile(resolve, reject,data, [profile]);
      });
      p4.then(function(data){
        var finalPortfolio=[{"profiles":portfolio}];
        finalMerger(data,finalPortfolio[0],function(data){
          res.json(data);
        });
      });
    });
});
});
module.exports = router;
