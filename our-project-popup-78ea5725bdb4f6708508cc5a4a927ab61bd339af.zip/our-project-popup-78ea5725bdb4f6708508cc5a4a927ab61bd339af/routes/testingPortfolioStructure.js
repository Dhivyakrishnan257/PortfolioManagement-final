var express = require('express');
var router = express.Router();
var mongodb = require('mongodb');
var mongoClient = mongodb.MongoClient;
var url = 'mongodb://10.219.85.96:27017/Portfolio-Management';
router.get('/testingPortfolioStructure/:id',function(req,res)
{
    mongoClient.connect(url, function(err, db) {
        if (err) {

        } else {
                var cursor = db.collection('projectDefinition');
                var o_id=require('mongodb').ObjectID(req.param('id'));
                cursor.find({"_id":o_id}).toArray(function(err,data){
                  if(err){
                    throw err;
                  }else {
                    res.json(data);
                  }
                });
                }
            });

    });
module.exports = router;
