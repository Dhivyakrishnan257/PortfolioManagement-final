var express = require('express');
var router = express.Router();
var request = require('request');
var mongoUtil = require('../db/mongoUtil');
var jwt = require('jsonwebtoken');
var path = require('path');
router.post('/authenticate', function(req, res) {
var object = req.body;
var db = mongoUtil.getConnection();
db.collection('authenticate').find({email:req.body.email,password:req.body.password}).toArray(function(err, doc) {
     if (err) {
       handleError(res, err.message, "Failed.");

     } else {
       if(doc.length>0){

    var token =  jwt.sign({
      user_id: doc[0]._id,
      email: doc[0].email,
      userProfileId:doc[0].userProfileId
    },"matta",{
      expiresIn : 86400
    });
    var user = {
      token: token,
      userId: doc[0].userProfileId
    };

    res.status(201).json(user);
  }else{
    res.status(403).send();
  }
  }
 });

 });
router.use(function(req, res, next) {
   var token = req.headers['x-access-token'];
   if (token) {
     jwt.verify(token, 'matta', function(err, decoded) {
       if (err) {
         return res.json({ success: false, message: 'Failed to authenticate token.' });
       } else {
         req.decoded = decoded;
         next();
       }
     });

   } else {
     return res.status(403).send({
         success: false,
         message: 'No token provided.'
     });
   }
 });

module.exports = router;
