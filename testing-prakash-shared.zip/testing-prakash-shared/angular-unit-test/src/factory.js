angular.module('myApp',[])
  .factory('Person', function (visitor, $http) {
    return function Person (name) {
      // ...
      this.create = function () {
        return $http.post('/people', this);
      };
    };
  });
