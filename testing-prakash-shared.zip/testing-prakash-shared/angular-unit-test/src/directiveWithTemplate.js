angular.module('docsIsolateScopeDirective', [])
  .directive('myCustomer', function() {
    return {
      restrict: 'E',
      scope: {
        customerInfo: '=info'
      },
      templateUrl: 'view/my-customer.html'
    };
  });
