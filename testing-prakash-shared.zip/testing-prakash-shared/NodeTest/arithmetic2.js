module.exports = function() {
    
    this.sum = function(num1, num2) {
        return num1 + num2;
    }
    
    this.subtract = function(num1,num2) {
        return num1-num2;
    }
    
    this.name = "Krishna";
};
