
function sumNew(num1, num2) {
        return num1 + num2;
}
    
function subtractNew(num1,num2) {
        return num1-num2;
}

function multiplyNew(num1,num2) {
        return num1*num2;
}

var myName = "Bharat";

module.exports = {
	sum : sumNew,
	subtract: subtractNew,
	name: myName	
}