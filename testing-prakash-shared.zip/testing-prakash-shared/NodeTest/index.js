var arithmetic1 = require('./arithmetic1');
console.log(arithmetic1.name);
console.log(arithmetic1.sum(10,20));
console.log(arithmetic1.subtract(10,20));


var arithmetic3 = require('./arithmetic3');
console.log(arithmetic3.name);
console.log(arithmetic3.sum(10,20));
console.log(arithmetic3.subtract(10,20));


var arithmetic2 = require('./arithmetic2');
var arithmetic2obj = new arithmetic2();
console.log(arithmetic2obj.name);
console.log(arithmetic2obj.sum(10,20));
console.log(arithmetic2obj.subtract(10,20));


//console.log("hello");