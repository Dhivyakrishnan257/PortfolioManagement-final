
var sumNew = function(num1, num2) {
        //return num1 + num2;
        return sumOld(num1,num2);
}

function sumOld(num1,num2)
{
	return num1*num2;
}


exports.sum = sumNew;


exports.subtract = function(num1,num2) {
        return num1-num2;
};

var myName = "Testing";
exports.name = myName;

/*
exports.name = "Arithmetic1";
*/
