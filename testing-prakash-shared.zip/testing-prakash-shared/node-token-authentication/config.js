module.exports = {

	'secret': 'ilovescotchyscotch',
	'database': 'mongodb://localhost:27017/jwt',
	'serverFolder': '/vagrant/NodeApp',
	'userName': 'admin',
	'password': 'root@1234'

};